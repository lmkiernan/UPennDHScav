//
//  Untitled.swift
//  HW 3
//
//  Created by liam on 11/9/24.
//

import Foundation
import CoreLocation

struct DiningHall {
    var text: String
    var collected: Bool
    var coordinate: CLLocation
}
