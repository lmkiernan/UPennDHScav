//
//  Scav_HuntTests.swift
//  Scav HuntTests
//
//  Created by liam on 11/12/24.
//

import Testing
@testable import Scav_Hunt

struct Scav_HuntTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
