//
//  Scav_HuntApp.swift
//  Scav Hunt
//
//  Created by liam on 11/12/24.
//

import SwiftUI

@main
struct Scav_HuntApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
