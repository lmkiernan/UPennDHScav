//
//  GameState.swift
//  HW 3
//
//  Created by liam on 11/11/24.
//
enum GameState {
    case loading
    case error
    case good
}
